from django.apps import AppConfig


class ServicepermissionsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core.servicePermissions'
    label = 'servicePermissions'
