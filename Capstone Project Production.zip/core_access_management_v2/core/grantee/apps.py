from django.apps import AppConfig


class GranteeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core.grantee'
    label = 'grantee'
