from django.apps import AppConfig


class SitemanagerConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core.siteManager'
    label = 'siteManager'
