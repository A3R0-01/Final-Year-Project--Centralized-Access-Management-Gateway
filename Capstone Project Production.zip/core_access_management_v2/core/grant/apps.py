from django.apps import AppConfig


class GrantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core.grant'
    label = 'grant'
