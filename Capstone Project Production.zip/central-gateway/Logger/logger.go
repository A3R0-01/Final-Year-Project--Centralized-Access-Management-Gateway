package logger

type Logger struct {
}

func (l *Logger) HandleServe()
